import axios from 'axios'

const handler = async(m, { conn }) => {

async function listDNSRecords() {
    const apiKey = '54kx4yvi3CBqomC99WSaqZo9tbxHoe9U-ncBIVMx';
    const zoneId = 'cada0ecef8f1e8d904435d469aef1b05';

    const headers = {
        'Authorization': `Bearer ${global.key}`,
        'Content-Type': 'application/json',
    };

    try {
        const response = await axios.get(`https://api.cloudflare.com/client/v4/zones/${global.zone}/dns_records`, { headers });
        if (response.status === 200) {
            m.reply("Daftar DNS Records:");
            response.data.result.forEach(record => {
                m.reply(`Type: ${record.type}, Name: ${record.name}, Content: ${record.content}`);
            });
        } else {
            m.reply(`Gagal mengambil daftar DNS. Kode status: ${response.status}`);
        }
    } catch (error) {
        m.reply('Terjadi kesalahan:', error.message);
    }
}

// Contoh penggunaan:
listDNSRecords();
}

handler.help = ['listdns']
handler.tags = ['owner']
handler.command = /^(listdns)$/i

handler.rowner = true

export default handler