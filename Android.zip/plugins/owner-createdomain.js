import axios from 'axios'

const handler = async(m, { conn, text }) => {
    if(!text) throw `Example: .domain ip | name`
    await m.reply('LOADING')

async function createSubdomain(subdomain, ip) {
    
    const headers = {
        'Authorization': `Bearer ${global.key}`,
        'Content-Type': 'application/json',
    };

    const data = {
        type: 'A',
        name: `${subdomain}.${global.domain}`,
        content: ip,
    };
    try {
        const response = await axios.post(`https://api.cloudflare.com/client/v4/zones/${global.zone}/dns_records`, data, { headers });
        if (response.status === 200) {
            m.reply(`Subdomain ${subdomain}.${global.domain} berhasil dibuat.`);
        } else {
            m.reply(`Gagal membuat subdomain. Kode status: ${response.status}`);
        }
    } catch (error) {
        m.reply('Terjadi kesalahan:', error.message);
    }

}

// Contoh penggunaan:
const rawdata = text
const dataArray = rawdata.split('|')
const subdomain = `${dataArray[1]}`;

const ip = `${dataArray[0]}`;

createSubdomain(subdomain, ip);
}

handler.help = ['domain host|name']
handler.tags = ['owner']
handler.command = /^(domain)$/i

handler.rowner = true

export default handler