let handler = async (m, { conn, usedPrefix }) => {
	let chat = global.db.data.chats[m.chat]
	if (chat.isBanned === false) {
		m.reply('Chat ini tidak dalam keadaan mute.')
		return
	}
	chat.isBanned = false
	await m.reply('Bot berhasil di unmute pada chat ini.')
}
handler.help = ['unmute']
handler.tags = ['group']
handler.command = ['unmute']

handler.admin = true
handler.group = true

export default handler