let handler = async (m, { conn, usedPrefix }) => {
	let chat = global.db.data.chats[m.chat]
	if (chat.isBanned === true) {
		m.reply('Chat ini sudah dalam keadaan mute.')
		return
	}
	chat.isBanned = true
	await m.reply('Bot berhasil di mute pada chat ini.')
}
handler.help = ['mute']
handler.tags = ['group']
handler.command = ['mute']

handler.admin = true
handler.group = true

export default handler