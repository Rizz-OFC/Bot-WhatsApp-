const handler = async(m, { text }) => {
    if(!text) throw `*INPUT PANJANG PW*\n example: .genpw 8`
    await m.reply(msg.wait)
    const pw = genpw(text)
    
    const reply = `
*BERIKUT PASSWORD ANDA*
* JUMLAH DIGIT: ${text}
* PASSWORD: ${pw}

${info.wm}
`
    m.reply(reply)
}

handler.help = ['genpw <panjang pw>', 'createpw']
handler.tags = ['tools']
handler.command = /^(genpw|createpw)$/i

export default handler 

function genpw(length = 8) {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+~`|}{[]:;?><,./-=";
  let password = "";

  for (let i = 0; i < length; ++i) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }
  return password;
}