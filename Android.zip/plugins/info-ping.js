import { performance } from 'perf_hooks'

let handler = async (m, { conn }) => {
    let old = performance.now()
    let neww = performance.now()
    let speed = Math.floor(neww - old)

    m.reply(`*🏓 Pong!* Latency is *${speed}ms*`)
}

handler.help = ['ping']
handler.tags = ['info']
handler.command = ['ping', 'speed']

export default handler