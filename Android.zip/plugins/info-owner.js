const handler = async(m, { conn }) => {
    const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${info.namaowner}\n`
            + 'ORG:My Owner Handsome;\n'
            + `TEL;type=CELL;type=VOICE;waid=${info.nomorowner}:+62 12345 67890\n`
            + 'END:VCARD'
    
    conn.sendMessage(m.chat, {
                     contacts: {
                     displayName: 'tod',
                     contacts: [{vcard}]
                     }
                     })
}

handler.help = ['owner']
handler.tags = ['info']
handler.command = /^(owner)$/i

export default handler