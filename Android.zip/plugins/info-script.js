const handler = async(m) => {
    m.reply(`
*SELL SCRIPT CYBER MULTI-DEVICE*
* HARGA: 50K
* TOTAL FITUR: 1000+

https://wa.me/62815420548390
       *100% NO ENC*
`)
}

handler.help = ['script', 'sc']
handler.tags = ['info']
handler.command = /^(script|sc)$/i

export default handler