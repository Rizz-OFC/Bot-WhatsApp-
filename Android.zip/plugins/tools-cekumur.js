const handler = async (m, {
    text
}) => {
    if(!text) throw `
*MASUKKAN TAHUN LAHIR ANDA*
CONTOH: .cekumur 1945
`
    const umurmu = await cekUmur(text)
    m.reply(`UMURMU SEKARANG ADALAH: ${umurmu} TAHUN`)
}

handler.help = ['cekumur']
handler.tags = ['tools']
handler.command = /^(cekumur)$/i

export default handler 

function cekUmur(tahunLahir) {
    var tahunSekarang = new Date().getFullYear();
    var umur = tahunSekarang - tahunLahir;
    return umur;
}
