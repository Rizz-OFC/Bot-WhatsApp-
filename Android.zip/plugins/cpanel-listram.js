const handler = async(m) => {
    const text = `
> *LISTRAM CPANEL Cyber-MultiDevice*

╭───⌜ *list* ⌟───
│• .1gb
│• .2gb
│• .3gb
│• .4gb
│• .5gb
│• .6gb
│• .7gb
│• .8gb
╰───────
`
    m.reply(text)
}

handler.help = ['listram']
handler.tags = ['cpanel']
handler.command = /^(listram)$/i

export default handler