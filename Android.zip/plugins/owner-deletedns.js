import axios from 'axios'

const handler = async(m, { conn, text }) => {
  if(!text) throw `masikan domain yang akan dihapuskan`


async function deleteSubdomain(subdomain) {
    const apiKey = 'pjhf3hxPfQ3OJZpyCkWuyageOy2nQExj-0_UHBd0';
    const zoneId = '0ab58446cce49c1f14fff5a724e92837';
    const domain = 'rizzdev.my.id';
    const headers = {
        'Authorization': `Bearer ${global.key}`,
        'Content-Type': 'application/json',
    };

    try {
        const response = await axios.get(`https://api.cloudflare.com/client/v4/zones/${global.zone}/dns_records`, { headers });
        if (response.status === 200) {
            const dnsRecords = response.data.result;
            const subdomainRecord = dnsRecords.find(record => record.name === `${subdomain}.${global.domain}`);
            if (subdomainRecord) {
                const deleteResponse = await axios.delete(`https://api.cloudflare.com/client/v4/zones/${global.zone}/dns_records/${subdomainRecord.id}`, { headers });
                if (deleteResponse.status === 200) {
                    m.reply(`Subdomain ${subdomain}.${global.domain} berhasil dihapus.`);
                } else {
                    m.reply(`Gagal menghapus subdomain. Kode status: ${deleteResponse.status}`);
                }
            } else {
                m.reply(`Subdomain ${subdomain}.${global.domain} tidak ditemukan.`);
            }
        } else {
            m.reply(`Gagal mengambil daftar DNS. Kode status: ${response.status}`);
        }
    } catch (error) {
        m.reply('Terjadi kesalahan:', error.message);
    }
}

// Contoh penggunaan:
const subdomainToDelete = 'subdomain';
deleteSubdomain(text);
}
handler.help = ['deletedns']
handler.tags = ['owner']
handler.command = /^(deletedns|dd)$/i

handler.rowner = true

export default handler