import fetch from "node-fetch";

const handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `[!] Input *Text*`, m)
  try {
    const web = await fetch(`https://aemt.me/gpt4?text=${text}`)
    const result = await web.json()
    conn.reply(m.chat, result.result, m)
  } catch (e) {
    conn.reply(m.chat, e.message, m)
  }
}

handler.help = ['gpt4', 'openai']
handler.tags = ['ai']
handler.command = /^((open)?ai)$/i
handler.limit = true
export default handler